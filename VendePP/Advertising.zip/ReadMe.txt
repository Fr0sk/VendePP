Grupo: T7G03
Filipe Coelho - 201500072
Lu�s Cruz - 201303248

Os objetivos indicados foram todos cumpridos. N�s ach�mos a parte da publicidade pouco expl�cita e bastante confusa acerca da forma da implementa��o. Ainda assim, implement�mos de acordo com aquilo que pens�mos ser o pedido.